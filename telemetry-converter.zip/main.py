import json
from datetime import datetime

# Function to convert Format 1 data (ISO timestamps)
def convert_from_format_1(data):
    """
    Converts Format 1 telemetry data:
    - Converts ISO 8601 timestamps to milliseconds
    - Renames 'temp' to 'temperature'
    - Renames 'hum' to 'humidity'
    """
    converted = []
    for entry in data:
        # Parse ISO timestamp and convert to milliseconds
        dt = datetime.fromisoformat(entry['timestamp'].replace('Z', '+00:00'))
        timestamp_ms = int(dt.timestamp() * 1000)
        
        # Create new entry with renamed keys
        converted_entry = {
            'timestamp': timestamp_ms,
            'temperature': entry['temp'],
            'humidity': entry['hum']
        }
        converted.append(converted_entry)
    
    return converted


# Function to convert Format 2 data (already in milliseconds)
def convert_from_format_2(data):
    """
    Converts Format 2 telemetry data:
    - Uses 'time' field (already in milliseconds) as 'timestamp'
    - Renames 'temperature_c' to 'temperature'
    - Renames 'humidity_percent' to 'humidity'
    """
    converted = []
    for entry in data:
        # Create new entry with renamed keys
        converted_entry = {
            'timestamp': entry['time'],
            'temperature': entry['temperature_c'],
            'humidity': entry['humidity_percent']
        }
        converted.append(converted_entry)
    
    return converted


# Main execution
def main():
    # Read data from both input files
    with open('data-1.json', 'r') as f:
        data_1 = json.load(f)
    
    with open('data-2.json', 'r') as f:
        data_2 = json.load(f)
    
    # Convert both datasets to unified format
    converted_1 = convert_from_format_1(data_1)
    converted_2 = convert_from_format_2(data_2)
    
    # Merge both datasets
    unified_data = converted_1 + converted_2
    
    # Sort by timestamp (ascending order)
    unified_data.sort(key=lambda x: x['timestamp'])
    
    # Write unified data to result file
    with open('data-result.json', 'w') as f:
        json.dump(unified_data, f, indent=2)
    
    # Print success message
    print("✅ Conversion complete! Unified data written to data-result.json")


if __name__ == '__main__':
    main()
