# Telemetry Data Converter

A Python utility that converts telemetry data from two different JSON formats into a unified, standardized format.

## Project Overview

This project reads telemetry data from two sources with different data structures and timestamps formats, then merges them into a single unified JSON file with consistent field names and timestamp formatting.

### What It Does

- **Format 1 Conversion**: Converts ISO 8601 timestamps to milliseconds and standardizes field names
- **Format 2 Conversion**: Standardizes field names from already-millisecond timestamps
- **Data Merging**: Combines both datasets into a single collection
- **Sorting**: Orders all entries chronologically by timestamp
- **Output**: Saves the unified data to `data-result.json`

## File Structure

\`\`\`
.
├── main.py              # Main conversion script
├── data-1.json          # Input file (Format 1: ISO timestamps)
├── data-2.json          # Input file (Format 2: millisecond timestamps)
├── data-result.json     # Output file (unified format)
└── README.md            # This file
\`\`\`

## How to Run

Simply execute the main script:

\`\`\`bash
python main.py
\`\`\`

You should see the success message:
\`\`\`
✅ Conversion complete! Unified data written to data-result.json
\`\`\`

## Input Formats

### Format 1 (data-1.json)
\`\`\`json
[
  {"timestamp": "2025-10-27T08:00:00Z", "temp": 22.5, "hum": 45},
  {"timestamp": "2025-10-27T08:10:00Z", "temp": 23.0, "hum": 47}
]
\`\`\`

### Format 2 (data-2.json)
\`\`\`json
[
  {"time": 1760006400000, "temperature_c": 24.5, "humidity_percent": 50},
  {"time": 1760007000000, "temperature_c": 24.7, "humidity_percent": 51}
]
\`\`\`

## Output Format (data-result.json)

\`\`\`json
[
  {
    "timestamp": 1760006400000,
    "temperature": 22.5,
    "humidity": 45
  },
  {
    "timestamp": 1760006600000,
    "temperature": 23.0,
    "humidity": 47
  },
  {
    "timestamp": 1760006400000,
    "temperature": 24.5,
    "humidity": 50
  },
  {
    "timestamp": 1760007000000,
    "temperature": 24.7,
    "humidity": 51
  }
]
\`\`\`

All entries are sorted by timestamp in ascending order, with consistent field names across both sources.

## Key Features

- Handles two different telemetry data formats
- Automatic timestamp normalization to milliseconds
- Consistent field naming across all data
- Chronological sorting of merged data
- Clean, well-commented code for easy understanding
